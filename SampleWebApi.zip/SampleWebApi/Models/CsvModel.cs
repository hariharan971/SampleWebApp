﻿using CsvHelper.Configuration;
using System.Globalization;

namespace SampleWebApi.Models
{
    public class CsvModel
    {
        public int OrderId { get; set; }
        public string ProductId { get; set; }
        public string CustomerId { get; set; }

        public string ProductName { get; set; }
        public string Category { get; set; }
        public string Region { get; set; }
        public string DateOfSale { get; set; }

        public int QuantitySold { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Discount { get; set; }
        public decimal ShippingCost { get; set; }

        public string PaymentMethod { get; set; }
        public string CustomerName { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerAddress { get; set; }
    }
    public sealed class CsvModelMap : ClassMap<CsvModel>
    {
        public CsvModelMap()
        {
            AutoMap(CultureInfo.InvariantCulture);
            Map(m => m.OrderId).Index(0).Default(0);
            Map(m => m.ProductId).Index(1).Default(null);
            Map(m => m.CustomerId).Index(2).Default(null);
            Map(m => m.ProductName).Index(3).Default(null);
            Map(m => m.Category).Index(4).Default(null);
            Map(m => m.Region).Index(5).Default(null);
            Map(m => m.DateOfSale).Index(6).Default(null);
            Map(m => m.QuantitySold).Index(7).Default(null);
            Map(m => m.UnitPrice).Index(8).Default(null);
            Map(m => m.Discount).Index(9).Default(null);
            Map(m => m.ShippingCost).Index(10).Default(null);
            Map(m => m.PaymentMethod).Index(11).Default(null);
            Map(m => m.CustomerName).Index(12).Default(null);
            Map(m => m.CustomerEmail).Index(13).Default(null);
            Map(m => m.CustomerAddress).Index(14).Default(null);
        }
    }
}
