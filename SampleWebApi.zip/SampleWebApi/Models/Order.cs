﻿namespace SampleWebApi.Models
{
    public class Order
    {
        public Order()
        {
            Items = new();
        }
        public int OrderId { get; set; }
        public DateTime DateOfSale { get; set; }
        public string Region { get; set; }
        public decimal ShippingCost { get; set; }
        public string PaymentMethod { get; set; }
        public int CustomerId { get; set; }
        public Customer Customer { get; set; }
        public List<OrderItem> Items { get; set; }
    }

}
