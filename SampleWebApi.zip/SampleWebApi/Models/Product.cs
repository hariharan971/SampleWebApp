﻿namespace SampleWebApi.Models
{
    public class Product
    {
        public Product() 
        {
            OrderItems = new();
        }
        public string ProductId { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public List<OrderItem> OrderItems { get; set; }
    }
}
