﻿using Microsoft.AspNetCore.Mvc;
using SampleWebApi.Processor.IProcessor;

namespace SampleWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WebAPIController : ControllerBase
    {
        protected readonly IEntityProcessor entityProcessor;
        public WebAPIController(IEntityProcessor entityProcessor) 
        {
            this.entityProcessor = entityProcessor;
        }
        [HttpPost("upload")]
        public async Task<IActionResult> UploadCsv(IFormFile file)
        {
            using var stream = file.OpenReadStream();
            await entityProcessor.UploadCsv(stream);
            return Ok("CSV Loaded");
        }

        [HttpGet("revenue")]
        public async Task<IActionResult> GetRevenue([FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
        {
            var total = await entityProcessor.GetTotalRevenue(startDate, endDate);
            return Ok(new { totalRevenue = total });
        }
    }
}
