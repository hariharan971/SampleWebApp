﻿using Microsoft.EntityFrameworkCore;
using SampleWebApi.Data;
using SampleWebApi.Models;
using SampleWebApi.Repository.IRepository;
using System.Collections.Generic;

namespace SampleWebApi.Repository
{
    public class EntityRepository : IEntityRepository
    {
        private readonly ApplicationDbContext context;
        public EntityRepository(ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task SaveProducts(List<CsvModel> lstRecords)
        {
            try
            {
                foreach (var productGroup in lstRecords.GroupBy(r => r.ProductId))
                {
                    var first = productGroup.First();
                    var product = new Product
                    {
                        ProductId = first.ProductId,
                        Name = first.ProductName,
                        Category = first.Category,
                        Description = string.Empty
                    };

                    context.Products.Add(product);
                }
                await context.SaveChangesAsync();

            }
            catch (Exception ex)
            {

            }
        }
        public async Task SaveCustomers(List<CsvModel> lstRecords)
        {
            try
            {
                foreach (var customerGroup in lstRecords.GroupBy(r => r.CustomerEmail))
                {
                    var first = customerGroup.First();
                    var customer = new Customer
                    {
                        Name = first.CustomerName,
                        Email = first.CustomerEmail,
                        Address = first.CustomerAddress
                    };

                    context.Customers.Add(customer);
                }

                await context.SaveChangesAsync();

            }
            catch (Exception ex)
            {

            }
        }

        public async Task SaveCsvModel(List<CsvModel> lstRecords)
        {
            try
            {
                foreach (var item in lstRecords.GroupBy(s=>s.OrderId))
                {
                    var last = item.MaxBy(s=>s.DateOfSale);
                    var customer = await context.Customers
                        .FirstOrDefaultAsync(c => c.Email == last.CustomerEmail);

                    var product = await context.Products
                        .FirstOrDefaultAsync(p => p.ProductId == last.ProductId);
                    

                    var order = new Order
                    {
                        OrderId = last.OrderId,
                        DateOfSale = DateTime.Parse(last.DateOfSale),
                        Region = last.Region,
                        PaymentMethod = last.PaymentMethod,
                        ShippingCost = last.ShippingCost,
                        Customer = customer,
                        Items = new List<OrderItem>
                {
                    new OrderItem
                    {
                        Product = product,
                        Quantity = last.QuantitySold,
                        UnitPrice = last.UnitPrice,
                        Discount = last.Discount
                    }
                    }
                    };

                    context.Orders.Add(order);
                    
                }

                await context.SaveChangesAsync();

            }
            catch (Exception ex)
            {

            }
        }

        public async Task<decimal> GetTotalRevenue(DateTime StartDate, DateTime EndDate)
        {
            return await context.OrderItems.Where(s => s.Order.DateOfSale >= StartDate && s.Order.DateOfSale <= EndDate)
                .SumAsync(i => (i.UnitPrice * i.Quantity) * (1 - i.Discount));
        }
    }
}
