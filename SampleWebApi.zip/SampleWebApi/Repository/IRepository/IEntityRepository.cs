﻿using SampleWebApi.Models;

namespace SampleWebApi.Repository.IRepository
{
    public interface IEntityRepository
    {
        Task SaveProducts(List<CsvModel> lstRecords);
        Task SaveCustomers(List<CsvModel> lstRecords);
        Task SaveCsvModel(List<CsvModel> lstRecords);
        Task<decimal> GetTotalRevenue(DateTime startDate, DateTime endDate);
    }
}
