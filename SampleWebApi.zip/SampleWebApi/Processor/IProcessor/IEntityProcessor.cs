﻿using Microsoft.AspNetCore.Mvc;
using SampleWebApi.Models;

namespace SampleWebApi.Processor.IProcessor
{
    public interface IEntityProcessor
    {
        Task UploadCsv(Stream csvStream);
        Task<decimal> GetTotalRevenue(DateTime startDate, DateTime endDate);
    }
}
