﻿using CsvHelper;
using Microsoft.EntityFrameworkCore;
using SampleWebApi.Models;
using SampleWebApi.Processor.IProcessor;
using SampleWebApi.Repository.IRepository;
using System.Formats.Asn1;
using System.Globalization;

namespace SampleWebApi.Processor
{
    public class EntityProcessor : IEntityProcessor
    {
        private readonly IEntityRepository entityRepository;
        public EntityProcessor(IEntityRepository entityRepository)
        {
            this.entityRepository = entityRepository;
        }

        public async Task UploadCsv(Stream csvStream)
        {
            using var reader = new StreamReader(csvStream);
            using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);
            csv.Context.RegisterClassMap<CsvModelMap>();
            var records = csv.GetRecords<CsvModel>().ToList();
            await entityRepository.SaveProducts(records);
            await entityRepository.SaveCustomers(records);
            await entityRepository.SaveCsvModel(records);
        }
        public async Task<decimal> GetTotalRevenue(DateTime startDate, DateTime endDate)
        {
            return await entityRepository.GetTotalRevenue(startDate, endDate);
        }
    }
}
